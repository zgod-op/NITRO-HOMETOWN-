# 🌏 Discord.js Bot Tutorial

## 📄 Description
Please don't just copy paste the code, but you need to learn how this code will work, because we both learn

## 📚 Social Media
- [Youtube Channel](https://www.youtube.com/channel/UCS1P0f3H20_CKxGVvACFWBg)
- [Discord Server](https://discord.gg/8rUvTYhFqK)
- Discord: [SadesXD#3971](https://discord.gg/8rUvTYhFqK)

## 📎 Usage
- Import this github into your project, or you can download this project
 
 
<img src="https://cdn.discordapp.com/attachments/777509514890313758/792403274007314492/unknown.png" alt="Github">


- You need to setup your User ID, Bot Prefix, Command Logs in file called `config.json`

- Set Your Bot Token in file called `.env` 

- More Tutorial: [Youtube Channel](https://www.youtube.com/channel/UCS1P0f3H20_CKxGVvACFWBg)
